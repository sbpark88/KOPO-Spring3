package com.kopo.bean;

public class Book {
	public int idx;
	public String name;
	public String phone;
	
	public String created;
	public String updated;
	
//	public final String DB_FILE_NAME = "c:\\tomcat\\book.db";
	public final String DB_FILE_NAME = "/Users/saebyul/SqliteDB/1007book.db";
	public final String TABLE_NAME = "book";
	
	public Book() {
		
	}
	
	public Book(String name, String phone) {
		this.name = name;
		this.phone = phone;
	}
	
	public Book(int idx, String name, String phone) {
		this.idx = idx;
		this.name = name;
		this.phone = phone;
	}
	
	public String toHtmlString() {
		StringBuffer htmlString = new StringBuffer();
		htmlString.append("<tr>");
		htmlString.append("<td>" + this.idx + "</td>");
		htmlString.append("<td>" + this.name + "</td>");
		htmlString.append("<td>" + this.phone + "</td>");
		htmlString.append("<td>" + "<a href='u1?idx=" + this.idx + "'>상세보기</a>" + "</td>");
		htmlString.append("<td>" + "<a href='d1?idx=" + this.idx + "'>삭제하기</a>" + "</td>");
		htmlString.append("</tr>");
		
		return htmlString.toString();
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public int getIdx() {
		return idx;
	}

	public String getCreated() {
		return created;
	}

	public String getUpdated() {
		return updated;
	}
}
